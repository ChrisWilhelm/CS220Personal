//Chris Wilhelm
//cwilhel8

#include <stdio.h>

int main() {
  printf("The second prize goes to Brandon.\n");
}
