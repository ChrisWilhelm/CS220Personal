#ifndef FUNCTIONS_H
#define FUNCTIONS_H

float div(float a, float b) {
  return a / b;
}

float mul(float a, float b) {
  return a * b;
}

int fac(int a) {
  if (a >= 0) {
    int fac = 1;
    while(a > 0) {
      fac = fac * a;
      a--;
    }
    return fac;
  }
  else {
    return 0;
  }
}

#endif

