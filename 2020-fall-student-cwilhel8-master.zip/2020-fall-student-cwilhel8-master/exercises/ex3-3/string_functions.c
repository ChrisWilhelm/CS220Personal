#include <stdio.h>
#include <string.h>
#include "string_functions.h"

/*
    Returns in the third argument the concatenation of the first
    argument and the second argument, provided that there is
    sufficient space in third argument, as specified by the fourth.
    e.g.
        concat("alpha", "beta", result, 10) puts "alphabeta" into result and returns 0
        concat("alpha", "gamma", result, 10) puts nothing into result and returns 1
*/
int concat(const char word1[], const char word2[], char result[], int result_capacity){

  int word1length = strlen(word1);
  int word2length = strlen(word2);
  int i = 0;
  if (word1length + word2length < result_capacity) {
    for(int j = 0; j < word1length; j++) {
      result[i] = word1[j];
      i++;
    }
    for(int k = 0; k < word2length; k++) {
      result[i] = word2[k];
      i++;
    }
    result[i] = '\0';
    return 0;
  }
   //NOTE: you may not use the strcat or strcpy library functions in your solution!
  return 1;

}



  /* Note: What happens if the user enters more than 10 characters
           when prompted for word1 or word2?  After you finish the
           rest of this exercise, try it out.

           We need to learn a safer way to collect strings from the user...stay tuned!
  */

