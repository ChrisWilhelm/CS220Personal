#include <iostream>
#include <vector>

using std::cout; 
using std::endl; 
using std::vector;

void sum(vector<int> v, int& result) {
  // TODO: complete the function to calculate the sum
  // of all v's values. Make use of references.
  int num = v.size();
  for(int i = 0; i < num; i++) {
    result += v[i];
  }
}

int main() {
  vector<int> v;
  for (int i = 0; i < 87; i = i + 2) {
      v.push_back(i);
  }
  int result = 0;
  sum (v, result);
  cout << "sum of all v's elements is: " << result << endl;
  
  return 0;
}
