//Chris Wilhelm cwilhel8

#include "language_model.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>

using std::cin;
using std::fstream;
using std::getline;
using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::map;
using std::ifstream;

int read(string fileName, string operation, string word1, string word2) {
  map<string,int> trigram;
  string line;
  ifstream infile1(fileName);
  if(infile1.is_open()) {
    while(infile1 >> line) {
      ifstream fs(line);
      if(fs.is_open() != true) {
	cerr << "Invalid file: " << line << endl;
      }
      else {
	string temp;
	string word1 = "<START_1>";
	string word2 = "<START_2>";
	string word3;
	while (fs >> word3) {
	  temp = word1 + " " + word2 + " " + word3;
	  trigram[temp] = trigram[temp] + 1;
	  temp.clear();
	  word1 = word2;
	  word2 = word3;
	  word3.clear();
	  temp.clear();
	}
	word3 = "<END_1>";
	for(int i = 0; i < 2; i++) {
	  temp = word1 + " " + word2 + " " + word3;
	  trigram[temp] = trigram[temp] + 1;
	  temp.clear();
	  word1 = word2;
	  word2 = word3;
	  word3 = "<END_2>";
	  temp.clear();
	}
      }
    }
  }
  else {
    cerr<< "Invalide file list: " << fileName << endl;
    return 1;
  }
  if(operation.compare("a") == 0) {
    print(trigram);
  }
  else if(operation.compare("d") == 0) {
    printRev(trigram);
  }
  else if(operation.compare("c") == 0) {
    printCount(trigram);
  }
  else if(operation.compare("f") == 0) {
    if(word1.empty() || word2.empty()) {
      cerr << "Invalid argument list: f requires two additional command-line arguments" << endl;
      return 3;
    }
    string match = word1 + " " + word2 + "\0";
    printFind(trigram, match);
  }
  else{
    cerr << "Invalid command: valid options are a, d, c, and f" << endl;
    return 2;
  }
  return 0;
}

void print(map<string, int> trigram) {
  for(map<string, int> ::const_iterator it = trigram.cbegin(); it != trigram.cend(); ++it) {
    cout << it->second << " - [" << it->first << "]\n";
  }
}

void printRev(map<string, int> trigram) {
  for(map<string, int> ::reverse_iterator rit = trigram.rbegin(); rit != trigram.rend(); ++rit) {
    cout << rit->second << " - [" << rit->first << "]\n";
  }
}

void printCount(map<string, int> trigram) {
  int max = 0;
  for(map<string, int> ::const_iterator it = trigram.cbegin(); it != trigram.cend(); ++it) {
    if(it->second > max) {
      max = it->second;
    }
  }
  for(int i = max; i > 0; i--) {
    for(map<string, int> ::const_iterator it = trigram.cbegin(); it != trigram.cend(); ++it) {
      if(i == it->second) {
	cout << it->second << " - [" << it->first << "]\n";
      }
    }
  }
}

void printFind(map<string, int> trigram, string match) {
  int num = 0;
  string finish = " ";
  for(map<string, int> ::const_iterator it = trigram.cbegin(); it != trigram.cend(); ++it) {
    string temp = it->first;
      //string last;
    std::size_t found = temp.find_last_of(" ");
    string last = temp.substr(0, found);
    if(last.compare(match) == 0 && it->second > num) {
      num = it->second;
      finish.clear();
      finish = it->first;
    }
  }
  if(num > 0) {
    cout << num << " - [" << finish << "]\n";
  }
  else {
    cout << "No trigrams of the form [" << match << " ?]" << endl;
  }
}
