//Chris Wilhelm cwilhel8
#include "language_model.h"
#include <map>
#include <string>
#include <iostream>
using std::map;
using std::string;
using std::cerr;
using std::endl;

int main(int argc, char *argv[]) {
  int val;
  if (argc >= 3) {
    string f = "f\0";
    string check = argv[2];
    if(argc == 5) {
      return val = read(argv[1], argv[2], argv[3], argv[4]);
    }
    else {
      return val = read(argv[1], argv[2], "\0", "\0");
    }
  }
  else {
    cerr << "Missing one or more essential arguments: file name, operation or both." << endl;
    return 0;
  }
}
