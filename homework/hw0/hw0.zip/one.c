//Chris Wilhelm
//cwilhel8

#include <stdio.h>

int main() {
  printf("The third prize goes to Emily.\n");
}
