//Chris Wilhelm
//cwilhel8

#include <stdio.h>

int main() {
  printf("The first prize goes to Sophi.\n");
}
